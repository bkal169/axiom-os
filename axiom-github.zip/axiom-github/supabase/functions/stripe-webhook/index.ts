import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { crypto } from "https://deno.land/std@0.177.0/crypto/mod.ts";

const STRIPE_WEBHOOK_SECRET = Deno.env.get("STRIPE_WEBHOOK_SECRET")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

// Map price IDs to tiers
const PRICE_TO_TIER: Record<string, string> = {
  "price_1T6CbrIXCHwjUw9LoHzI5csk": "PRO",
  "price_1T6CbtIXCHwjUw9LAPBaPM4y": "PRO_PLUS",
  "price_1T6CbqIXCHwjUw9LsqExucPa": "ENTERPRISE",
};

function tierFromPriceId(priceId: string): string {
  return PRICE_TO_TIER[priceId] || "FREE";
}

async function verifyStripeSignature(
  body: string,
  signature: string,
  secret: string
): Promise<boolean> {
  const parts = signature.split(",").reduce((acc: Record<string, string>, part) => {
    const [key, val] = part.split("=");
    acc[key] = val;
    return acc;
  }, {});

  const timestamp = parts["t"];
  const sig = parts["v1"];
  if (!timestamp || !sig) return false;

  const payload = `${timestamp}.${body}`;
  const keyData = new TextEncoder().encode(secret);
  const msgData = new TextEncoder().encode(payload);

  const cryptoKey = await crypto.subtle.importKey(
    "raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const signatureBuffer = await crypto.subtle.sign("HMAC", cryptoKey, msgData);
  const computedSig = Array.from(new Uint8Array(signatureBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  return computedSig === sig;
}

Deno.serve(async (req) => {
  const body = await req.text();
  const signature = req.headers.get("stripe-signature") || "";

  if (!(await verifyStripeSignature(body, signature, STRIPE_WEBHOOK_SECRET))) {
    return new Response("Invalid signature", { status: 401 });
  }

  const event = JSON.parse(body);
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

  // Idempotency check
  const { data: existing } = await supabase
    .from("subscription_events")
    .select("id")
    .eq("stripe_event_id", event.id)
    .single();

  if (existing) return new Response("Already processed", { status: 200 });

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object;
        const userId = session.metadata?.supabase_user_id;
        if (!userId) break;

        // Fetch full subscription details
        const subRes = await fetch(
          `https://api.stripe.com/v1/subscriptions/${session.subscription}`,
          { headers: { Authorization: `Bearer ${Deno.env.get("STRIPE_SECRET_KEY")}` } }
        );
        const sub = await subRes.json();
        const priceId = sub.items?.data?.[0]?.price?.id;
        const tier = tierFromPriceId(priceId);

        await supabase.from("user_profiles").update({
          subscription_tier: tier,
          stripe_customer_id: session.customer,
          stripe_subscription_id: session.subscription,
          stripe_price_id: priceId,
          stripe_current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
        }).eq("id", userId);

        await supabase.from("subscription_events").insert({
          user_id: userId,
          event_type: "checkout.session.completed",
          stripe_event_id: event.id,
          stripe_subscription_id: session.subscription,
          stripe_customer_id: session.customer,
          price_id: priceId,
          plan: tier,
          status: "active",
          current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
        });
        break;
      }

      case "customer.subscription.updated": {
        const sub = event.data.object;
        const priceId = sub.items?.data?.[0]?.price?.id;
        const tier = tierFromPriceId(priceId);

        const { data: profile } = await supabase
          .from("user_profiles")
          .select("id")
          .eq("stripe_subscription_id", sub.id)
          .single();

        if (profile) {
          await supabase.from("user_profiles").update({
            subscription_tier: tier,
            stripe_price_id: priceId,
            stripe_current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
          }).eq("id", profile.id);

          await supabase.from("subscription_events").insert({
            user_id: profile.id,
            event_type: "customer.subscription.updated",
            stripe_event_id: event.id,
            stripe_subscription_id: sub.id,
            stripe_customer_id: sub.customer,
            price_id: priceId,
            plan: tier,
            status: sub.status,
          });
        }
        break;
      }

      case "customer.subscription.deleted": {
        const sub = event.data.object;
        const { data: profile } = await supabase
          .from("user_profiles")
          .select("id")
          .eq("stripe_subscription_id", sub.id)
          .single();

        if (profile) {
          await supabase.from("user_profiles").update({
            subscription_tier: "FREE",
            stripe_subscription_id: null,
            stripe_price_id: null,
          }).eq("id", profile.id);

          await supabase.from("subscription_events").insert({
            user_id: profile.id,
            event_type: "customer.subscription.deleted",
            stripe_event_id: event.id,
            stripe_subscription_id: sub.id,
            stripe_customer_id: sub.customer,
            plan: "FREE",
            status: "cancelled",
          });
        }
        break;
      }

      case "invoice.payment_succeeded":
      case "invoice.payment_failed": {
        const invoice = event.data.object;
        const { data: profile } = await supabase
          .from("user_profiles")
          .select("id")
          .eq("stripe_customer_id", invoice.customer)
          .single();

        if (profile) {
          await supabase.from("subscription_events").insert({
            user_id: profile.id,
            event_type: event.type,
            stripe_event_id: event.id,
            stripe_subscription_id: invoice.subscription,
            stripe_customer_id: invoice.customer,
            status: event.type === "invoice.payment_succeeded" ? "paid" : "failed",
            metadata: { amount: invoice.amount_paid || invoice.amount_due },
          });
        }
        break;
      }
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Webhook error:", err);
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
});
